﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
 using UnityEngine.SceneManagement;

public class ballscript : MonoBehaviour {

public Vector2 jumpforce = new Vector2 (300,300);
 public Vector2 axis = new Vector2 (30,0);
  public Vector2 ters = new Vector2 (300,-30);
   public Vector2 duz = new Vector2 (300,30);
public Text scoreboard;
public Button Restart;
public int score=0;

 Rigidbody2D rB2D;
 Vector3 originalPos;
	// Use this for initialization

void OnCollisionEnter2D(Collision2D col) {
 //her hangi bir objeye çarptığında çalışır
 if (col.gameObject.tag == "Finish" ) {
 //tagı Cupe olan bir objeye çarptığında çalışır
 
//Debug.Log("asarak"+i);
 
//i++;
scoreboard.text="Game Over. Score:"+score.ToString();

 Time.timeScale = 0.0F;


 }




 

 }


	void Start () {
rB2D = GetComponent<Rigidbody2D>();
originalPos = new Vector3(gameObject.transform.position.x, gameObject.transform.position.y, gameObject.transform.position.z);
		Restart.onClick.AddListener(TaskOnClick);
	}
	
void TaskOnClick(){
	score =0 ;
	scoreboard.text="0";
 SceneManager.LoadScene(SceneManager.GetActiveScene().name);
}


	// Update is called once per frame
	void Update () {
		
		///transform.Translate(axis);

	if(Input.GetKeyUp("space"))
	rB2D.AddForce(jumpforce);

	if(GameObject.FindGameObjectWithTag("Player").transform.position.x > -2.3 && GameObject.FindGameObjectWithTag("Player").transform.position.x< -2 &&  GameObject.FindGameObjectWithTag("Player").transform.position.y>1.9 && GameObject.FindGameObjectWithTag("Player").transform.position.y< 2.1) 
{
	jumpforce = ters;
	score++;
	scoreboard.text=score.ToString();
	}

if(GameObject.FindGameObjectWithTag("Player").transform.position.x < -8 && GameObject.FindGameObjectWithTag("Player").transform.position.x> -9 &&  GameObject.FindGameObjectWithTag("Player").transform.position.y>1 && GameObject.FindGameObjectWithTag("Player").transform.position.y< 2) 
{
	jumpforce = duz;
	score++;
	scoreboard.text=score.ToString();
	}


}
}
